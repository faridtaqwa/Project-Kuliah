<?php $__env->startSection('content'); ?>
<div class="container shadow">
	<div class="row">
		<div class="col"><a class ="btn btn-primary btn-spirit" style="color: white;" href="/admin/tim">Back</a></div>
	</div>
	<div class="dash_r">
		<table class="table table-striped">
  <thead class="thead-dark">
    <tr>
      <th scope="col">1</th>
      <th scope="col">Nama Tim</th>
      <th scope="col">Jenis</th>
      <th scope="col">Status</th>
      <th scope="col">Ketua tim</th>
      <th scope="col">Detail</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $tims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($tim->id); ?></th>
      <td><?php echo e($tim->nama); ?></td>
      <td><?php echo e($tim->jenis); ?></td>
      <td><?php echo e($tim->status); ?></td>
      <td>
          <?php if(is_null($tim->idKetua)): ?>
            <button type="button" style="margin: 0px;" class="btn btn-primary btn-spirit" data-toggle="modal" data-target="#ketua<?php echo e($tim->id); ?>">
            Pilih ketua </button>
        
          <?php else: ?>
          <?php echo e(DB::table('relawans')->where('id', $tim->idKetua)->value('namaDepan')); ?> <?php echo e(DB::table('relawans')->where('id', $tim->idKetua)->value('namaBelakang')); ?>

          <?php endif; ?>
      </td>
      <td><button type="button" style="margin: 0px;" class="btn btn-primary btn-spirit" data-toggle="modal" data-target="#tim<?php echo e($tim->id); ?>">
  Details
</button></td>
    </tr>
    <div class="modal fade" id="tim<?php echo e($tim->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Detail tim</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Anggota Tim:
        <?php
          $members = DB::table('relawans')->where('idTim', $tim->id)->get();
        ?>
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($member->namaDepan); ?> <?php echo e($member->namaBelakang); ?> <br/>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-spirit" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="ketua<?php echo e($tim->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Detail</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="padding: 30px">
        <form method="POST">
                        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($tim->id); ?>">
       <select name="idKetua">
        <?php
          $members = DB::table('relawans')->where('idTim', $tim->id)->get();
        ?>
         <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value=<?php echo e($member->id); ?>><?php echo e($member->namaDepan); ?> <?php echo e($member->namaBelakang); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-secondary btn-spirit">Simpan</button>
        </form>
      </div>
    </div>
  </div>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>