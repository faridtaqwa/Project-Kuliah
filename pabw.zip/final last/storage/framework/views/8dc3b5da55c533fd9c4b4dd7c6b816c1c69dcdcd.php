<?php $__env->startSection('content'); ?>
<div class="container shadow">
	<div class="row">
		<div class="col"><a class ="btn btn-primary btn-spirit" style="color: white;" href="/admin/tim">Back</a></div>
    <div class="col"><a class ="btn btn-primary btn-spirit" style="color: white; float: right;" href="/admin/tim/create">Tambah tim</a></div>
	</div>


	<div class="dash_r">
		<table class="table table-striped">
  <thead class="thead-spirit">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nama Tim</th>
      <th scope="col">Status</th>
      <th scope="col">Jumlah Anggota</th>
      <th scope="col">Ketua tim</th>
      <th scope="col">Detail</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $tims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($tim->id); ?></th>
      <td><?php echo e($tim->nama); ?></td>
      <td><?php echo e($tim->status); ?></td>
      <td>
        <?php
          $count = DB::table('relawans')->where('idTim', $tim->id)->count();
        ?>
        <?php echo e($count); ?>


      </td>
      <td>
          <?php if(is_null($tim->idKetua)): ?>
            <button type="button" style="margin: 0px;" class="btn btn-primary btn-spirit" data-toggle="modal" data-target="#ketua<?php echo e($tim->id); ?>">
            Pilih ketua </button>
        
          <?php else: ?>
          <?php echo e(DB::table('relawans')->where('id', $tim->idKetua)->value('namaDepan')); ?> <?php echo e(DB::table('relawans')->where('id', $tim->idKetua)->value('namaBelakang')); ?>

          <?php endif; ?>
      </td>
      <td><button type="button" style="margin: 0px;" class="btn btn-primary btn-spirit" data-toggle="modal" data-target="#tim<?php echo e($tim->id); ?>">
  Details
</button></td>
    </tr>
    <div class="modal fade" id="tim<?php echo e($tim->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Detail tim</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div style="font-weight: bold;font-size: 120%;text-align: center;">Anggota Tim</div>
        <?php
          $members = DB::table('relawans')->where('idTim', $tim->id)->get();
        ?>
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row" style="margin-top: 20px;">
            <div class="col">
              <div class="cropfotomed"><img src="<?php echo e(url('uploads/file/'.$member->file)); ?>" class="foto" ></div>
            </div>
          </div>
          <div class="row"style="margin-top: 10px; text-transform: capitalize;">
            <div class="col" style="text-align: center; font-weight: bold;"><?php echo e($member->namaDepan); ?> <?php echo e($member->namaBelakang); ?></div>
          </div>
          <div class="row"style="text-transform: capitalize;">
            <div class="col" style="text-align: center;"><?php echo e($member->profesi); ?></div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-spirit" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="ketua<?php echo e($tim->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Pilih ketua tim</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="padding: 30px">
        <form method="POST">
                        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($tim->id); ?>">
       <select name="idKetua" class="form-control">
        <?php
          $members = DB::table('relawans')->where('idTim', $tim->id)->get();
        ?>
         <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value=<?php echo e($member->id); ?>><?php echo e($member->namaDepan); ?> <?php echo e($member->namaBelakang); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-secondary btn-spirit">Simpan</button>
        </form>
      </div>
    </div>
  </div>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($tims->links()); ?>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>