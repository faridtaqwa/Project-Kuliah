<?php $__env->startSection('content'); ?>
<div class="container shadow">
	<div class="row">
		<div class="col"><a class ="btn btn-primary btn-spirit" style="color: white;" href="/admin/dashboard">Back</a>
    </div>
  </div>
  <div class="dash_r">
  <div class="row">
    <div class="col"><a href="/admin/relawan"><img src="/image/relawan.svg" width="80%"></a><label>Daftar relawan</label></div>
    <div class="col">
      <a class ="btn btn-primary btn-spirit" style="color: white;" href="/admin/tim/data">Lihat tim</a>
    </div>
    <div class="col">
      <a class ="btn btn-primary btn-spirit" style="color: white;" href="/admin/tim/create">Buat tim</a>
    </div>
  </div>
  </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>