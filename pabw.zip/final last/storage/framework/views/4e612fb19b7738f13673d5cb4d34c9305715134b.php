<?php $__env->startSection('content'); ?>
<div class="container shadow">
<div class="row">
   <div class="col"><a class ="btn btn-primary btn-spirit" style="color: white;" href="/admin/mobilisasi">Back</a></div>
</div>
<form method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col">
        <div class="form-group">
            <label>Nama Tim</label>
            <select class="form-control" name="idTim">
                <?php $__currentLoopData = $timsiap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tim->id); ?>"><?php echo e($tim->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
          </div>
          <div class="col">
        <div class="form-group">
            <label>Posko tujuan</label>
            <select class="form-control" name="idPosko">
                 <?php $__currentLoopData = $poskos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($posko->id); ?>"><?php echo e($posko->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    </div>
    <div class="row">
        <div class="col">
        <div class="form-group">
            <label>Tanggal mulai</label>
            <input type="date" name="tanggalMulai" class="form-control" required="">
        </div>
        </div>
        <div class="col">
        <div class="form-group">
            <label>Tanggal berakhir</label>
            <input type="date" name="tanggalBerakhir" class="form-control" required="">
        </div>
        </div>
    
    </div>
    <button type="submit" class="btn btn-primary btn-spirit"> Submit </button>


</form>


</div>

<div class="container shadow">
<h1 style="color: black;">Mobilisasi tim</h1>
<table class="table table-striped">
  <thead class="thead-dark">
    <tr>
      <th scope="col">id</th>
      <th scope="col">Nama Tim</th>
      <th scope="col">Posko Tujuan</th>
      <th scope="col">Tanggal mulai</th>
      <th scope="col">Tanggal berakhir</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $mobilisasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobilisasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($mobilisasi->id); ?></td>
        <td><?php echo e($mobilisasi->tim['nama']); ?></td>
        <td><?php echo e($mobilisasi->posko['nama']); ?></td>
        <td><?php echo e($mobilisasi->tanggalMulai); ?></td>
        <td><?php echo e($mobilisasi->tanggalBerakhir); ?></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

</div>
































<?php $__env->stopSection(); ?>
<?php echo $__env->make('masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>