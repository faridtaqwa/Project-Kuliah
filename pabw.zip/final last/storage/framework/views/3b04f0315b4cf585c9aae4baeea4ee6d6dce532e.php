<?php $__env->startSection('content'); ?>
<div class="container shadow">
	<div class="row">
		<div class="col">Admin</div>
	</div>
	<div class="dash_r">
		<div class="row img_r">
		<div class="col"><a href="/admin/tim"><img src="/image/tim.svg" width="80%"></a></div>
		<div class="col"><a href="/admin/mobilisasi"><img src="/image/mobilisasi.svg" width="80%"></a></div>
		<div class="col"><a href="/admin/laporan"><img src="/image/evaluasi.svg" width="80%"></a></div>
		</div>
		<div class="row text_r">
		<div class="col">Pengelolaan tim dan relawan</div>
		<div class="col">Mobilisasi tim</div>
		<div class="col">Evaluasi tim</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>