<?php $__env->startSection('content'); ?>
<div class="container shadow">
	<div class="row">
		<div class="col"><a class ="btn btn-primary btn-spirit" style="color: white;" href="/dashboard">Back</a></div>
	</div>
	<div class="row">
		<div class="col" style="text-align: center;">Tulis Laporan</div>
	</div>
	<div class="dash_r">
		<?php if(Auth::user()->id == Auth::user()->tim['idKetua']): ?>
			<?php
			$mobilisasi=DB::table('mobilisasis')->where('idTim', Auth::user()->idTim)->first();
			?>
				<?php if(is_null($mobilisasi->laporan)): ?>
					<form method="post">
  						<?php echo e(csrf_field()); ?>

  			

						<div class="row">
  					<div class="col">
  					<div class="form-group">
    					<label>Isi laporan</label>
    					<textarea required="" type="text" name="laporan" class="form-control" placeholder="Isi" rows="10"></textarea>
  						</div>
  						</div>
							</div>
							<div class="row">
  							<div class="col">
  									<div class="form-group">
    					<input type="submit" name="Kirim" class="btn btn-primary btn-spirit " style="float: right;">
  								</div>
  							</div>
						</div>

						</form>
				<?php else: ?>
				Anda sudah mengirim laporan
				<?php endif; ?>

		<?php else: ?>
		
			Hanya ketua yang menulis laporan
		<?php endif; ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>