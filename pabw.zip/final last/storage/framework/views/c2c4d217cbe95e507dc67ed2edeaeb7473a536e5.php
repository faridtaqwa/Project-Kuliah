<?php $__env->startSection('content'); ?>
<div class="container shadow">
	<div class="row">
		<div class="col"><a class ="btn btn-primary btn-spirit" style="color: white;" href="/admin/tim/data">Back</a></div>
	</div>
    
<div class="row" style="margin-top: 20px;">
  <form method="POST" action="<?php echo e(url('admin/tim')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>
    <div class="col-sm">
      <div class="form-group">
    <label>Nama</label>
    <input required="" type="text" name="nama" class="form-control" placeholder="Nama tim">
  </div>
    </div>
    <div class="col-sm">
    <input type="submit" class="btn btn-primary btn-spirit" style="margin-top: 15px;">
    </div>

</div>


</form>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>