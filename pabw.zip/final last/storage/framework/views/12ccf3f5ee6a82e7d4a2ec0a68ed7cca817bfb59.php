<?php $__env->startSection('content'); ?>
<div class="container shadow">
	<div class="row">
		<div class="col"><a class ="btn btn-primary btn-spirit" style="color: white;" href="dashboard">Back</a></div>
	</div>
	<div class="row">
		<div class="col" style="text-align: center;">Mobilisasi</div>
	</div>
	<div class="row">
		<div class="col" style="text-align: center;"><?php echo e(Auth::user()->tim['nama']); ?></div>
	</div>
	<div class="dash_r">
		<div class="row img_r">
		<div class="col"><img src="/image/Mobilisasi.svg" width="100%"></div>
		<div class="col" style="padding: 30px;">
			<div class="row">
				<div class="col">POSKO TUJUAN: <?php echo e($mobilisasi->posko['nama']); ?></div>
			</div>
			<div class="row">
				<div class="col">ALAMAT POSKO: <?php echo e($mobilisasi->posko['alamat']); ?></div>
			</div>
			<div class="row">
				<div class="col">TANGGAL MULAI: <?php echo e($mobilisasi->tanggalMulai); ?></div>
			</div>
			<div class="row">
				<div class="col">TANGGAL BERAKHIR: <?php echo e($mobilisasi->tanggalBerakhir); ?></div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>