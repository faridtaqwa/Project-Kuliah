<?php $__env->startSection('content'); ?>
<div class="container shadow">
	<div class="row">
		<div class="col-2"><a class ="btn btn-primary btn-spirit" style="color: white;" href="/admin/tim">Back</a>
    </div>
    <div class="col-10">
      <form method="post" class="form-group form-inline" style="float: right;">
        <?php echo csrf_field(); ?>
      <select name="idprov" class="form-control">
        <option selected="selected">Pilih Provinsi</option>
        <option value="0">SEMUA</option>
        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($province->id); ?>"><?php echo e($province->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <button type="submit" class="btn btn-primary btn-spirit" name="formfilter" style="margin-left: 10px;">FILTER</button>
      </form>
    </div>
	</div>
	<div class="dash_r">
		<table class="table table-striped">
  <thead class="thead-spirit">
    <tr>
      <th scope="col" style="color: white;">ID</th>
      <th scope="col">Nama</th>
      <th scope="col">Profesi</th>
      <th scope="col">Kota</th>
      <th scope="col">Provinsi</th>
      <th scope="col">Tim</th>
      <th scope="col">Details</th>
    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $relawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr style="text-transform: lowercase;text-transform: capitalize;"> 
      <th scope="row"><?php echo e($relawan->id); ?></th>
      <td><?php echo e($relawan->namaDepan); ?> <?php echo e($relawan->namaBelakang); ?></td>
      <td><?php echo e($relawan->profesi); ?></td>
      <td><?php echo e($relawan->kot['name']); ?></td>
      <td><?php echo e($relawan->prov['name']); ?></td>
      <td>
          <?php if(is_null($relawan->idTim)): ?>
            <button type="button" style="margin: 0px;" class="btn btn-primary btn-spirit" data-toggle="modal" data-target="#tim<?php echo e($relawan->id); ?>">
            Pilih tim </button>
        
          <?php else: ?>
            <?php echo e($relawan->tim['nama']); ?>

    
          <?php endif; ?>
      </td>
      <td> <button type="button" style="margin: 0px;" class="btn btn-primary btn-spirit" data-toggle="modal" data-target="#detail<?php echo e($relawan->id); ?>">
  Details
</button></td>
    </tr>
    <div class="modal fade" id="detail<?php echo e($relawan->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Detail</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="padding: 30px">
        <div class="row" style="margin-bottom: 20px">
         <div class="col">
          <div class="cropfoto"><img src="<?php echo e(url('uploads/file/'.$relawan->file)); ?>" class="foto" ></div>
         </div>
        </div>
        <div class="row">
          <div class="col">
            Nama
          </div>
          <div class="col" style="text-transform: capitalize;">
            : <?php echo e($relawan->namaDepan); ?> <?php echo e($relawan->namaBelakang); ?>

          </div>
        </div>
        <div class="row">
          <div class="col">
            Tanggal Lahir
          </div>
          <div class="col">
            : <?php echo e($relawan->tanggalLahir); ?>

          </div>
        </div>
        <div class="row">
          <div class="col">
            Jenis Kelamin
          </div>
          <div class="col">
            : <?php echo e($relawan->jenisKelamin); ?>

          </div>
        </div>
        <div class="row">
          <div class="col">
            Profesi
          </div>
          <div class="col">
            : 
            <?php echo e($relawan->profesi); ?>

          </div>
        </div>
        <div class="row">
          <div class="col">
            Jenis Kelamin
          </div>
          <div class="col">
            : <?php echo e($relawan->noHp); ?>

          </div>
        </div>
        <div class="row">
          <div class="col">
            Email
          </div>
          <div class="col">
            : <?php echo e($relawan->email); ?>

          </div>
        </div>
        <div class="row">
          <div class="col">
            Provinsi
          </div>
          <div class="col">
            : <?php echo e($relawan->prov['name']); ?>

          </div>
        </div>
        <div class="row">
          <div class="col">
            Kota
          </div>
          <div class="col">
            : <?php echo e($relawan->kot['name']); ?>

          </div>
        </div>
        <div class="row">
          <div class="col">
            Kecamatan
          </div>
          <div class="col">
            : <?php echo e($relawan->kec['name']); ?>

          </div>
        </div>
        <div class="row">
          <div class="col">
            Kelurahan
          </div>
          <div class="col">
            : <?php echo e($relawan->kel['name']); ?>

          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-spirit" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="tim<?php echo e($relawan->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Detail</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="padding: 30px">
        <div class="form-group">
          
        <form method="POST">
                        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($relawan->id); ?>">
       <select name="idTim" class="form-control">
         <?php $__currentLoopData = $timsiap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value=<?php echo e($tim->id); ?>><?php echo e($tim->nama); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-secondary btn-spirit" name="formtim">Simpan</button>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
   

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($relawans->links()); ?>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>