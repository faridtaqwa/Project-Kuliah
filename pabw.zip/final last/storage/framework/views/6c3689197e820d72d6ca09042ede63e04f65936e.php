<?php $__env->startSection('content'); ?>
<div class="container shadow">
    <div class="row">
        <div class="col">$name</div>
    </div>
    <div class="dash_r">
        <div class="row img_r">
        <div class="col"><a href="/relawan/tim"><img src="/image/tim.svg" width="250px"></a></div>
        <div class="col"><a href="/relawan/mobilisasi"><img src="/image/mobilisasi.svg"width="250px"></a></div>
        <div class="col"><a href="/relawan/laporan"><img src="/image/evaluasi.svg"width="250px"></a></div>
        </div>
        <div class="row text_r">
        <div class="col">Lihat Tim</div>
        <div class="col">Mobilisasi Tim</div>
        <div class="col">Tulis Laporan</div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master_relawan', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>