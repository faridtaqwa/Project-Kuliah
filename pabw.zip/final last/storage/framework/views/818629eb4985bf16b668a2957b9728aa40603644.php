<?php $__env->startSection('content'); ?>
  <div class="container-fluid h-100">
    <div class="row h-100">
    <div class="col-sm left">
      <img class="logo" src="/image/spirit.svg">
      <hr>
      <h1><b> Sistem Pengelolaan <br/>Tim Penanggulangan Bencana </b></h1>
    </div>
    <div class="col-sm right">
      <h5>LOGIN RELAWAN</h5>
      <div class="login-box shadow">
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
          <table class="form-group">
            <tr>
              <td>
                 <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>
               <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
               </td>
            </tr>
            <tr>
              <td>
               <button type="submit" class="btn btn-primary btn-block btn-login">
                LOGIN
               </button>
               </td>
            </tr>
          </table>
        </form>
      </div>
      
    </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlogin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>