<?php $__env->startSection('content'); ?>
<div class="container shadow">
	<div class="row">
		<div class="col"><a class ="btn btn-primary btn-spirit" style="color: white;" href="/dashboard">Back</a></div>
	</div>
	<?php if(is_null(Auth::user()->idTim)): ?>

		<div class="row">
			<div class="col">
				Kamu belum punya tim, tunggu update dari admin.
			</div>
		</div>

	<?php else: ?>
	<div class="row">
		<div class="col" style="text-align: center;"><?php echo e(Auth::user()->tim['nama']); ?></div>
	</div><div class="row">
		<div class="col" style="text-align: center;">
		Ketua tim: 
		<?php
		$ketua = DB::table('relawans')->where('id', Auth::user()->tim['idKetua'])->first();
		?>
			<?php echo e($ketua->namaDepan); ?> <?php echo e($ketua->namaBelakang); ?>

		</div>
	</div>
	<div class="dash_r">
		<?php
          $members = DB::table('relawans')->where('idTim', Auth::user()->idTim)->get();
        ?>
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
          <div class="col"><img src="/image/user.svg" class="rounded-circle"></div>
		<div class="col"> <?php echo e($member->namaDepan); ?> <?php echo e($member->namaBelakang); ?> <?php echo e($member->profesi); ?></div>
		</div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>