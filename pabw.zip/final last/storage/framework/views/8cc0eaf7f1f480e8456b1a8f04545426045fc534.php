<?php $__env->startSection('content'); ?>
<div class="container shadow">
	<div class="row">
		<div class="col"><a class ="btn btn-primary btn-spirit" style="color: white;" href="/dashboard">Back</a></div>
	</div>
	<?php if(is_null(Auth::user()->idTim)): ?>

		<div class="row">
			<div class="col" style="text-align: center;">
				Kamu belum punya tim, tunggu update dari admin.
			</div>
		</div>

	<?php elseif(is_null(Auth::user()->tim['idKetua'])): ?>
	<div class="row" style="font-size: 150%">
		<div class="col" style="text-align: center;font-weight: bolder; text-transform: uppercase;">Tim : <?php echo e(Auth::user()->tim['nama']); ?></div>
	</div><div class="row" style="margin-top: 5px;">
		<div class="col" style="text-align: center;font-weight: bolder; font-size: 120%;">
		Ketua tim: -
		</div>
	</div>
	<div class="dash_r">
		<?php
          $members = DB::table('relawans')->where('idTim', Auth::user()->idTim)->get();
          $i=0;
        ?>
        <div class="row" style="margin-bottom: 20px;">
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-4"><div class="cropfoto2"><img src=<?php echo e(url('uploads/file/'.$member->file)); ?> class="foto"></div><label style="display: block; text-align: center; margin: 30px;text-transform: capitalize;"><?php echo e($member->namaDepan); ?> <?php echo e($member->namaBelakang); ?> <br/><?php echo e($member->profesi); ?> <br/> <?php echo e($member->noHp); ?></label></div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
	</div>
	<?php else: ?>
	<div class="row" style="font-size: 150%">
		<div class="col" style="text-align: center;font-weight: bolder; text-transform: uppercase;">Tim : <?php echo e(Auth::user()->tim['nama']); ?></div>
	</div><div class="row" style="margin-top: 5px;">
		<div class="col" style="text-align: center;font-weight: bolder; font-size: 120%; text-transform: capitalize;">
		Ketua tim : 
		<?php
		$ketua = DB::table('relawans')->where('id', Auth::user()->tim['idKetua'])->first();
		?>
			<?php echo e($ketua->namaDepan); ?> <?php echo e($ketua->namaBelakang); ?>

		</div>
	</div>
	<div class="dash_r">
		<?php
          $members = DB::table('relawans')->where('idTim', Auth::user()->idTim)->get();
          $i=0;
        ?>
        <div class="row" style="margin-bottom: 20px;">
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-4"><div class="cropfoto2"><img src=<?php echo e(url('uploads/file/'.$member->file)); ?> class="foto"></div><label style="display: block; text-align: center; margin: 30px;text-transform: capitalize;"><b><?php echo e($member->namaDepan); ?> <?php echo e($member->namaBelakang); ?> </b><br/><?php echo e($member->profesi); ?> <br/> <?php echo e($member->noHp); ?></label></div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
	</div>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>