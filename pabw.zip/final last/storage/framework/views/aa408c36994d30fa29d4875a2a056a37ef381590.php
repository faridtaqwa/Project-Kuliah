<?php $__env->startSection('content'); ?>

<div class="container shadow">
  

    <div class="row">
        <div class="col">
            <div class="dropdown">
  <button class="btn btn-info btn-spirit dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="border-radius: 8px; padding-right: 15px;padding-left: 15px;">
    <?php echo e(Auth::user()->namaDepan." ".Auth::user()->namaBelakang); ?>

  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="/dashboard">Dashboard</a>
    <a class="dropdown-item" data-toggle="modal" data-target="#exampleModalCenter">Edit Data</a>
  </div>
          </div>
        </div>
    </div>
    <div class="row" style="margin-top: 20px;">
        <div class="col">

    </div>
</div>
<form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
<div class="row">
<?php if(count($errors) > 0): ?>
  <div class="alert alert-danger" role="alert">
   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <?php echo e($error); ?>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php endif; ?>
  <?php if(\Session::has('success')): ?>
  
  <?php endif; ?>
</div>

<div class="row">
  <div class="col-sm" style="padding-top: 10px; padding-bottom: 10px; font-weight: bolder;">
    Data Diri
  </div>
  
</div>
<div class="row">
    <div class="col-sm">
      <div class="form-group">
    <label>Nama Depan</label>
    <input required="" type="text" name="namaDepan" class="form-control" value ="<?php echo e(Auth::user()->namaDepan); ?>">
  </div>
    </div>
    <div class="col-sm">
      <div class="form-group">
    <label>Nama Belakang</label>
    <input required=""type="text" name="namaBelakang" class="form-control" value ="<?php echo e(Auth::user()->namaBelakang); ?>">
  </div>
    </div>
</div>
<div class="row">
    <div class="col-sm">
      <div class="form-group">
    <label>Profesi</label>
    <select required="" name="profesi" class="form-control">
      <option value="" selected disabled hidden>Pilih</option>
      <option value="dokter">Dokter</option>
      <option value="perawat">Perawat</option>
    </select>
  </div>
    </div>
    <div class="col-sm">
      <div class="form-group">
    <label>Tanggal lahir</label>
    <input required=""type="date" name="tanggalLahir" class="form-control">
  </div>
    </div>
</div>
<div class="row">
    <div class="col-sm">
      <div class="form-group">
    <label>Jenis kelamin</label>
    <select required=""name="jenisKelamin" class="form-control">
      <option value="" selected disabled hidden>Pilih</option>
      <option value="Laki-Laki">Laki-Laki</option>
      <option value="Perempuan">Perempuan</option>
    </select>
  </div>
    </div>
    <div class="col-sm">
      <div class="form-group">
    <label>No Telepon</label>
    <input required=""type="text" name="noHp" class="form-control" value="<?php echo e(Auth::user()->noHp); ?>">
  </div>
    </div>
</div>
<div class="row">
    <div class="col-sm">
      <div class="form-group">
    <label>Email</label>
    <input required=""type="email" name="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>">
  </div>
    </div>
    <div class="col-sm">
    
    </div>
</div>
<div class="row">
  <div class="col-sm">
      <div class="form-group">
    <label>Password</label>
    <input required=""type="password" name="password" class="form-control" placeholder="Password">
  </div>
    </div>
    <div class="col-sm">
      <div class="form-group">
    <label>Confirm Password</label>
   <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Confirm password" required>
  </div>
    </div>
</div>
<div class="row">
  <div class="col-sm" style="padding-top: 10px; padding-bottom: 10px; font-weight: bolder;">
    Alamat
  </div>
</div>
<div class="row">
  <div class="col-sm">
    <label>Provinsi</label>
    <select required=""name="provinsi" class="form-control">
      <option value="" selected disabled hidden>Pilih</option>
      <option value="1" >test</option>
    </select>
  </div>
  <div class="col-sm">
    <label>Kota</label>
    <select required=""name="kota" class="form-control">
      <option value="" selected disabled hidden>Pilih</option>
      <option value="1" >test</option>
    </select>
  </div>
</div>

<div class="row">
  <div class="col-sm">
    <label>Kecamatan</label>
    <select required=""name="kecamatan" class="form-control">
      <option value="" selected disabled hidden>Pilih</option>
      <option value="1" >test</option>
    </select>
  </div>
  <div class="col-sm">
    <label>Kelurahan</label>
    <select required=""name="kelurahan" class="form-control">
      <option value="" selected disabled hidden>Pilih</option>
      <option value="1" >test</option>
    </select>
  </div>
</div>

<div class="row">
  <div class="col-sm">
     <label>Kedepos</label>
    <input required=""type="text" name="kodepos" class="form-control" value="<?php echo e(Auth::user()->kodepos); ?>">
  </div>
  <div class="col-sm">
    <label>Alamat</label>
    <textarea required=""name="alamat" class="form-control"><?php echo e(Auth::user()->alamat); ?></textarea>
  </div>
</div>
<div class="row">
    <div class="col-sm">
  
    </div>
    <div class="col-sm">
    <input type="submit" class="btn btn-primary btn-spirit"  style="float: right; width: 150px;" data-toggle="modal" data-target="#exampleModalCenter">
    </div>
</div>


</form>
</div>
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>