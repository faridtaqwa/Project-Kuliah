<?php $__env->startSection('content'); ?>
  <div class="container-fluid h-100">
    <div class="row h-100">
    <div class="col-sm left">
      <img class="logo" src="/image/spirit.svg">
      <hr>
      <h1><b>Sistem Pengelolaan <br/>Tim Penanggulangan Bencana</b></h1>
    </div>
    <div class="col-sm right">
      <h5>LOGIN ADMIN</h5>
<?php if(\Session::has('alert')): ?>
                <div class="alert alert-danger" style="width: 80%;margin: auto;">
                    <div><?php echo e(Session::get('alert')); ?></div>
                </div>
            <?php endif; ?>
            <?php if(\Session::has('alert-success')): ?>
                <div class="alert alert-success">
                    <div><?php echo e(Session::get('alert-success')); ?></div>
                </div>
            <?php endif; ?>
      <div class="login-box shadow">
        <form action="<?php echo e(url('/loginPost')); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <table class="form-group">
            <tr>
              <td>
                <input type="email" name="email" placeholder="Email" class="form-control">
              </td>
            </tr>
            <tr>
              <td>
               <input type="password" name="password" placeholder="Password" class="form-control">
               </td>
            </tr>
            <tr>
              <td>
               <button type="submit" class="btn btn-primary btn-block btn-login">
                LOGIN
               </button>
               </td>
            </tr>
          </table>
        </form>
      </div>
      
    </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlogin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>