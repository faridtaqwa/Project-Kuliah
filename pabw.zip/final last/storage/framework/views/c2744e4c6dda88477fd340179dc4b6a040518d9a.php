<?php $__env->startSection('content'); ?>
<div class="container shadow">
	<div class="row">
		<div class="col"><a class ="btn btn-primary btn-spirit" style="color: white;" href="/admin/mobilisasi">Back</a></div>
	</div>
	<div class="dash_r">
		<table class="table table-striped">
  <thead class="thead-spirit">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nama Posko</th>
      <th scope="col">Alamat</th>
      <th scope="col">Map</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $poskos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($posko->id); ?></th>
      <td><?php echo e($posko->nama); ?></td>
      <td><?php echo e($posko->alamat); ?></td>
      <td><button type="button" class="btn btn-primary btn-spirit" data-toggle="modal" data-target="#myModal<?php echo e($posko->id); ?>">
      Map
    </button></td>
    </tr>
<div class="modal fade" id="myModal<?php echo e($posko->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
             <h4 class="modal-title" id="myModalLabel">Map</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        </div>
        <div class="modal-body">
          <iframe src="<?php echo e($posko->embed); ?>}" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
      </div>
    </div>
  </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>