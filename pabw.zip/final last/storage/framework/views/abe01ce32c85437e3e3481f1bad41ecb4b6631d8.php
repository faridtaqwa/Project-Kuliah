<?php $__env->startSection('content'); ?>
<div class="container shadow">
    
	<div class="row">
		<div class="col"><a class ="btn btn-primary btn-spirit" style="color: white;" href="/admin/dashboard">Back</a></div>
	</div>
	 <div class="dash_r">
    <div class="row img_r">
    <div class="col"><a href="/admin/mobilisasi/posko"><img src="/image/tim.svg" width="80%"></a></div>
    <div class="col"><a href="/admin/mobilisasi/kirimtim"><img src="/image/mobilisasi.svg" width="80%"></a></div>
    </div>
    <div class="row text_r">
    <div class="col">Lihat Posko</div>
    <div class="col">Mobilisasi tim</div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masteradmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>