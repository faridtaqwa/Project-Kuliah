<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class provinces extends Model
{
    protected $table ='provinces';
}
