<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
   <h3><?php echo $message; ?></h3>
    <p><?php echo anchor('pusdalops/beranda','Kembali ke beranda'); ?></p>
</body>
</html>