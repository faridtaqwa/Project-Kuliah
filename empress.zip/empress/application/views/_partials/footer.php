 <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>SHARELOG</span>
            </div>
          </div>
        </footer>